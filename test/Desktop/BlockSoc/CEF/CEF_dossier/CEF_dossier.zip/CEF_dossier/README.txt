The CEF is ran in 3 week intervals.

Presentation of sector and adjusted evaluation template and allocation of assets to analysts.

Analysts are given 2 weeks to analysis the asset they were assigned using our thesis as a guideline.
Create a 4-5 minute slideshow presentation of findings.

At the end of the second week, analysts present to the CEF and are graded by myself and Sean.

The analyst who scores the highest across thesis, presentation and discord contribtution recieves €100 worth of the 
asset they evaluated.

1 week break, then the net sector analysis begins


Documents included.

	3word docs
1. Evaluation Thesis for analysising Layer 1 infrastructure
2. Evaluation Thesis for analysising DeFi (improved on first thesis)
3. Example of DeFi analysis by one of our analysts

	2 images
1. Analyst_Guide, breakdown of grading system 
2. Guide to what we want to see from the theisis (information, layout, visuals) and Presentation.

